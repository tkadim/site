=== Random / Rotating Ads V2 ===
Contributors: datafeedr.com
Donate link: http://www.datafeedr.com/
Tags: ads, rotate, random, adverts, advertisement, google adsense, adsense deluxe, custom ads, random ads, rotating ads, 
Requires at least: 2.8
Stable tag: 2.0

The Datafeedr Random Ads V2 plugin allows you to simply and easily show random, rotating ads anywhere on your site by adding a template tag to your theme's template files or using widgets.

== Description ==

= IMPORTANT! =
THIS PLUGIN HAS BEEN DEPRECATED.
WE'VE RELEASED A BRAND NEW VERSION OF THIS PLUGIN.
THE NEW PLUGIN HAS MANY MORE FEATURES!
CHECK IT OUT HERE: <http://wordpress.org/extend/plugins/ads-by-datafeedrcom/>

The Datafeedr Random Ads V2 plugin allows you to simply and easily show random, rotating ads anywhere on your site by adding a template tag to your theme's template files or using widgets.

You can show ANY type of ad: Google Adsense, affiliate ads, banners, images, flash, text, etc...  There's no limit to the number of ads you can put into rotation for an ad spot.

== Installation ==

The most up-to-date installation instructions can be found here:

<a href="http://www.datafeedr.com/random-ads-plugin-v2.php">http://www.datafeedr.com/random-ads-plugin-v2.php</a>

== Frequently Asked Questions ==

Please visit our support forums if you have questions about this plugin:

<a href="http://www.datafeedr.com/forums/forumdisplay.php?f=42">http://www.datafeedr.com/forums/forumdisplay.php?f=42</a>