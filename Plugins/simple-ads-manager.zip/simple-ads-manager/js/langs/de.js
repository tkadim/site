tinyMCE.addI18n("de.samb", {
	insert_samb : 'Insert Advertisement',
  title: 'Insert Advertisement',
  description: 'Select Advertisement Object',
  ad: 'Insert Single Ad',
  place: 'Insert Ads Place',
  zone: 'Insert Ads Zone',
  block: 'Insert Ads Block'
});